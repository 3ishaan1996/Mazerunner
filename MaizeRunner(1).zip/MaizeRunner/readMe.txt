--The following file is to give the user the information about how to run the following program--

-> The main function is present in the file MazeSolver.py. Hence this should be the first file that must be run.
-> The file RandomMazeGen.py is the first part of the question that is used to generate the random mazes.
-> The MazeSolver also contains the code to implement all the algorithms.
-> The names for the rest are self explanatory.
